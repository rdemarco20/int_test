package com.rdemarco.tradingcards.resource;

import java.util.Map;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.rdemarco.tradingcards.db.PurchaseDb;
import com.rdemarco.tradingcards.model.Purchase;
import com.rdemarco.tradingcards.resource.TradingAppResource.PurchaseTouple;


public class TradingAppResosurceTest {
	
	TradingAppResource resource;
	PurchaseDb db = PurchaseDb.getInstance();
	
	@Before
	public void setUp() {
		resource = new TradingAppResource();
	}
	
	@After
	public void clearData() {
		db.getAllPurchases().clear();
	}
	
	@Test
	public void testConsolodateOrders_single() {
		db.addPurchase(new Purchase(1, "char", 50));
		db.addPurchase(new Purchase(2, "char", 30, 3));
		
		Map<String, PurchaseTouple> orders = resource.consolodateOrders();
		Assert.assertEquals(4, orders.get("char").quantity);
		Assert.assertEquals(140, orders.get("char").totalSales);
	}
	
	@Test
	public void testConsolodateOrders_multipleDifferentProducts() {
		db.addPurchase(new Purchase(1, "char", 50));
		db.addPurchase(new Purchase(2, "char", 30, 3));
		
		db.addPurchase(new Purchase(1, "pika", 110));
		db.addPurchase(new Purchase(2, "pika", 80, 2));
		
		Map<String, PurchaseTouple> orders = resource.consolodateOrders();
		Assert.assertEquals(4, orders.get("char").quantity);
		Assert.assertEquals(140, orders.get("char").totalSales);
		
		Assert.assertEquals(3, orders.get("pika").quantity);
		Assert.assertEquals(270, orders.get("pika").totalSales);
	}

}
