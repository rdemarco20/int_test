package com.rdemarco.tradingcards.message;

import org.junit.Assert;
import org.junit.Test;

import com.rdemarco.tradingcards.exception.UnknownMessageTypeException;

public class MessageHandlerFactoryTest {
	
	@Test
	public void testGetMessageHandlerInstance_messageType1() throws UnknownMessageTypeException {
		String msg = "1, Charizard, 5000";
		validateHandlerInstance(msg, SinglePurchaseHandler.class);
	}
	
	@Test
	public void testGetMessageHandlerInstance_messageType2() throws UnknownMessageTypeException {
		String msg = "2, Charizard, 5000, 2";
		validateHandlerInstance(msg, MultiplePurchaseHandler.class);
	}
	
	@Test
	public void testGetMessageHandlerInstance_messageType3() throws UnknownMessageTypeException {
		String msg = "3, Charizard, 500, add";
		validateHandlerInstance(msg, AdjustProductHandler.class);
	}
	
	@Test(expected = UnknownMessageTypeException.class)
	public void testGetMessageHandlerInstance_messageTypeUnknown() throws UnknownMessageTypeException {
		String msg = "4, Charizard, 500, add";
		MessageHandlerFactory.getMessageHandlerInstance(msg);
	}
	
	private void validateHandlerInstance(String message, Class<? extends MessageHandler> expectedHandler) throws UnknownMessageTypeException {
		MessageHandler instance = MessageHandlerFactory.getMessageHandlerInstance(message);
		Assert.assertEquals(instance.getClass(), expectedHandler);
	}

}
