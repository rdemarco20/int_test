package com.rdemarco.tradingcards.message;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.rdemarco.tradingcards.db.PurchaseDb;
import com.rdemarco.tradingcards.exception.InsufficientParametersException;
import com.rdemarco.tradingcards.model.Purchase;


public class SinglePurchaseHandlerTest {
	
	SinglePurchaseHandler handler;
	PurchaseDb db;
	
	@Before
	public void setUp() {
		db = PurchaseDb.getInstance();
	}
	
	@Test
	public void testHandleMessage_validMessage() throws InsufficientParametersException {
		String msg = "1,charizard, 5000 ";
		
		handler = new SinglePurchaseHandler(msg);
		handler.handleMessage(1);
		
		Purchase p = db.getAllPurchases().get(0);
		
		Assert.assertEquals(1, p.getId());
		Assert.assertEquals("charizard", p.getProduct());
		Assert.assertEquals(5000, p.getPrice());
		Assert.assertEquals(1, p.getQuantity());
	}
	
	@Test(expected=InsufficientParametersException.class)
	public void testHandleMessage_invalidMessage() throws InsufficientParametersException {
		String msg = "1,charizard,5000, oops ";
		
		handler = new SinglePurchaseHandler(msg);
		handler.handleMessage(1);
	}
}
