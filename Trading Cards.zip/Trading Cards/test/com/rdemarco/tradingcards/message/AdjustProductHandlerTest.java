package com.rdemarco.tradingcards.message;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.rdemarco.tradingcards.db.PurchaseDb;
import com.rdemarco.tradingcards.exception.InsufficientParametersException;
import com.rdemarco.tradingcards.model.Purchase;

public class AdjustProductHandlerTest {
	
	PurchaseDb purchaseDb;
	MessageHandler handler;
	
	@Before
	public void setUp() {
		purchaseDb = PurchaseDb.getInstance();
	}
	
	@After
	public void clearData() {
		purchaseDb.getAllPurchases().clear();
	}
	
	@Test
	public void testHandleMessage_add() throws InsufficientParametersException {
		Purchase p1 = new Purchase(1, "Charizard", 500);
		purchaseDb.addPurchase(p1);
		
		Purchase p2 = new Purchase(2, "Charizard", 300, 3);
		purchaseDb.addPurchase(p2);
		
		handler = new AdjustProductHandler("3, Charizard,add,20");
		handler.handleMessage(3);
		
		Assert.assertEquals(520, purchaseDb.getAllPurchases().get(0).getPrice());
		Assert.assertEquals(320, purchaseDb.getAllPurchases().get(1).getPrice());
		
		Assert.assertEquals("add 20", purchaseDb.getAllPurchases().get(0).getAdjustments().get(0));
		Assert.assertEquals("add 20", purchaseDb.getAllPurchases().get(1).getAdjustments().get(0));
	}
	

	@Test
	public void testHandleMessage_add_twoDifferentProducts() throws InsufficientParametersException {
		Purchase p1 = new Purchase(1, "Charizard", 500);
		purchaseDb.addPurchase(p1);
		
		Purchase p2 = new Purchase(2, "pikachu", 300, 3);
		purchaseDb.addPurchase(p2);
		
		handler = new AdjustProductHandler("3, Charizard,add,20");
		handler.handleMessage(3);
		
		Assert.assertEquals(520, purchaseDb.getAllPurchases().get(0).getPrice());
		Assert.assertEquals(300, purchaseDb.getAllPurchases().get(1).getPrice());
		
		Assert.assertEquals("add 20", purchaseDb.getAllPurchases().get(0).getAdjustments().get(0));
	}
	
	@Test
	public void testHandleMessage_subtract() throws InsufficientParametersException {
		Purchase p1 = new Purchase(1, "Charizard", 500);
		purchaseDb.addPurchase(p1);
		
		Purchase p2 = new Purchase(2, "pikachu", 300, 3);
		purchaseDb.addPurchase(p2);
		
		Purchase p3 = new Purchase(3, "Charizard", 200);
		purchaseDb.addPurchase(p3);
		
		handler = new AdjustProductHandler("3, Charizard,subtract,100");
		handler.handleMessage(4);
		
		Assert.assertEquals(400, purchaseDb.getAllPurchases().get(0).getPrice());
		Assert.assertEquals(300, purchaseDb.getAllPurchases().get(1).getPrice());
		Assert.assertEquals(100, purchaseDb.getAllPurchases().get(2).getPrice());
		
		Assert.assertEquals("subtract 100", purchaseDb.getAllPurchases().get(0).getAdjustments().get(0));
		Assert.assertEquals("subtract 100", purchaseDb.getAllPurchases().get(2).getAdjustments().get(0));

	}
	
	@Test
	public void testHandleMessage_multiply() throws InsufficientParametersException {
		Purchase p1 = new Purchase(1, "Charizard", 500);
		purchaseDb.addPurchase(p1);
		
		Purchase p2 = new Purchase(2, "pikachu", 300, 3);
		purchaseDb.addPurchase(p2);
		
		Purchase p3 = new Purchase(3, "Charizard", 200);
		purchaseDb.addPurchase(p3);
		
		handler = new AdjustProductHandler("3, Charizard,multiply,2");
		handler.handleMessage(4);
		
		Assert.assertEquals(1000, purchaseDb.getAllPurchases().get(0).getPrice());
		Assert.assertEquals(300, purchaseDb.getAllPurchases().get(1).getPrice());
		Assert.assertEquals(400, purchaseDb.getAllPurchases().get(2).getPrice());

		Assert.assertEquals("multiply 2", purchaseDb.getAllPurchases().get(0).getAdjustments().get(0));
		Assert.assertEquals("multiply 2", purchaseDb.getAllPurchases().get(2).getAdjustments().get(0));

	}
	
	

}
