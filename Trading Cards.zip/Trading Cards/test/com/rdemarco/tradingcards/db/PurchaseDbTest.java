package com.rdemarco.tradingcards.db;

import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.rdemarco.tradingcards.model.Purchase;

public class PurchaseDbTest {
	
	PurchaseDb purchaseDb;
	List<Purchase> allPurchases;
	Map<String, Integer> groupedProducts;
	
	@Before
	public void setUp() {
		purchaseDb = PurchaseDb.getInstance();
		allPurchases = purchaseDb.getAllPurchases();
		groupedProducts = purchaseDb.getGroupedProducts();
	}
	
	@After
	public void clearData() {
		allPurchases.clear();
		groupedProducts.clear();
	}
	
	@Test
	public void testSingleton() {
		Assert.assertEquals(purchaseDb, PurchaseDb.getInstance());
	}
	
	@Test
	public void testAddPurchase_singleProduct() {
		Purchase p1 = new Purchase(1, "Charizard", 500);
		purchaseDb.addPurchase(p1);
		
		Assert.assertTrue(allPurchases.contains(p1));
		Assert.assertEquals(Integer.valueOf(1), groupedProducts.get(p1.getProduct()));
	}
	
	@Test
	public void testAddPurchase_MultipleProduct_singleRequest() {
		Purchase p1 = new Purchase(1, "Charizard", 500, 3);
		purchaseDb.addPurchase(p1);
		
		Assert.assertTrue(allPurchases.contains(p1));
		Assert.assertEquals(Integer.valueOf(3), groupedProducts.get(p1.getProduct()));
	}
	
	@Test
	public void testAddPurchase_singleProduct_multiRequest() {
		Purchase p1 = new Purchase(1, "Charizard", 500);
		purchaseDb.addPurchase(p1);
		
		Purchase p2 = new Purchase(2, "Charizard", 500, 3);
		purchaseDb.addPurchase(p2);
		
		Assert.assertTrue(allPurchases.contains(p1));
		Assert.assertTrue(allPurchases.contains(p2));
		Assert.assertEquals(Integer.valueOf(4), groupedProducts.get(p1.getProduct()));
	}
	
	@Test
	public void testAddPurchase_singleProduct_differentProduct() {
		Purchase p1 = new Purchase(1, "Charizard", 500);
		purchaseDb.addPurchase(p1);
		
		Purchase p2 = new Purchase(2, "Pikachu", 300, 3);
		purchaseDb.addPurchase(p2);
		
		Assert.assertTrue(allPurchases.contains(p1));
		Assert.assertTrue(allPurchases.contains(p2));
		Assert.assertEquals(Integer.valueOf(1), groupedProducts.get(p1.getProduct()));
		Assert.assertEquals(Integer.valueOf(3), groupedProducts.get(p2.getProduct()));
	}
}
