Assumptions
I have assumed that there is no base product data, and that products are added on the fly as new input data is read.
I have assumed that we will allow a subtract op to result in a negative price.
That we are not implementing an actual rest service, since only 2 dependencies are allowed (and obviously junit is priority). It should be simple enough to swap out the Main class for a REST controller though.
