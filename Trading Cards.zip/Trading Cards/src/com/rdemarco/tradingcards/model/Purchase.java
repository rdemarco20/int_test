package com.rdemarco.tradingcards.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * This class will model a trading card purchase
 *
 */
public class Purchase {
	
	private long id;
	private String product;
	private int price;
	private int quantity;
	private List<String> adjustments;
	
	/**
	 * This will default quantity to 1
	 * @param product
	 * @param price
	 */
	public Purchase(long id, String product, int price) {
		this.id = id;
		this.product = product;
		this.price = price;
		this.quantity = 1;
		adjustments = new ArrayList<>();
	}
	
	/**
	 * @param product
	 * @param price
	 * @param quantity
	 */
	public Purchase(long id, String product, int price, int quantity) {
		this.id = id;
		this.product = product;
		this.price = price;
		this.quantity = quantity;
		adjustments = new ArrayList<>();
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getProduct() {
		return product;
	}
	
	public void setProduct(String product) {
		this.product = product;
	}
	
	public int getPrice() {
		return price;
	}
	
	public void setPrice(int price) {
		this.price = price;
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public void addAdjustment(String val) {
		adjustments.add(val);
	}
	
	public List<String> getAdjustments() {
		return Collections.unmodifiableList(adjustments);
	}

	@Override
	public String toString() {
		return "Purchase [id=" + id + ", product=" + product + ", price=" + price + ", quantity=" + quantity
				+ ", adjustments=" + adjustments + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Purchase other = (Purchase) obj;
		if (id != other.id)
			return false;
		return true;
	}
	
}
