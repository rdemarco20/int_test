package com.rdemarco.tradingcards;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import com.rdemarco.tradingcards.exception.InsufficientParametersException;
import com.rdemarco.tradingcards.exception.UnknownMessageTypeException;
import com.rdemarco.tradingcards.resource.TradingAppResource;

/**
 * Our fake server, which is "receiving" requests
 */
public class Main {

	private static String inputDataFile = "res/tradeData.txt";

	public static void main(String args[]) {
		TradingAppResource resource = new TradingAppResource();
		
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(inputDataFile));
			String line = reader.readLine();
			while (line != null) {
				resource.processMessage(line);
				line = reader.readLine(); //next line
			}
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}
