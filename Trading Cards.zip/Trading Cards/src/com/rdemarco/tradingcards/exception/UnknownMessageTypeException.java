package com.rdemarco.tradingcards.exception;

/**
 * Exception for an unsupported message type 
 *
 */
public class UnknownMessageTypeException extends Exception {

	private static final long serialVersionUID = 48581909278987673L;
	
	public UnknownMessageTypeException(String message) {
		super(message);
	}
}
