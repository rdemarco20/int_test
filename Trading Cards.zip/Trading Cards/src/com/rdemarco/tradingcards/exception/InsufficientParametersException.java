package com.rdemarco.tradingcards.exception;

public class InsufficientParametersException extends Exception {

	private static final long serialVersionUID = 7786494822880621947L;

	public InsufficientParametersException(String message) {
		super(message);
	}
}
