package com.rdemarco.tradingcards.resource;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.rdemarco.tradingcards.db.PurchaseDb;
import com.rdemarco.tradingcards.exception.InsufficientParametersException;
import com.rdemarco.tradingcards.exception.UnknownMessageTypeException;
import com.rdemarco.tradingcards.message.MessageHandler;
import com.rdemarco.tradingcards.message.MessageHandlerFactory;
import com.rdemarco.tradingcards.model.Purchase;

/**
 * This would be the simulated rest resource. It will handle incoming messages
 */
public class TradingAppResource {

	private static final int LOG_ORDERS_COUNT = 10;
	private static final int LOG_ORDER_ADJUSTMENTS_COUNT = 50;


	private int messageCount = 0;

	public void processMessage(String message) throws UnknownMessageTypeException, InsufficientParametersException {

		MessageHandler handler = MessageHandlerFactory.getMessageHandlerInstance(message);
		handler.handleMessage(messageCount);
		messageCount++;

		checkIfOrderProcessingReqired();
	}

	private void checkIfOrderProcessingReqired() {
		if (messageCount % LOG_ORDERS_COUNT == 0) {
			//print report of all orders 
			printSalesReport();
		} else if (messageCount % LOG_ORDER_ADJUSTMENTS_COUNT == 0) {
			//print report of all order amendments
			printAdjustmentReport();
		}
	}
	
	private void printSalesReport() {
		Map<String, PurchaseTouple> consolodatedOrders = consolodateOrders();

		System.out.println("\nTOTAL SALES FOR EACH PRODUCT");
		System.out.println("============================");
		//now print each product type
		for(Entry<String, PurchaseTouple> purchase : consolodatedOrders.entrySet()) {
			double priceInPounds =  purchase.getValue().totalSales / 100;
			System.out.println(String.format("Purchase: %s, Quantity Sold: %s, Total Sales: �%s", purchase.getKey(), purchase.getValue().quantity, String.format("%,.2f", priceInPounds)));
		}
		System.out.println("============================\n");
	}
	
	private void printAdjustmentReport() {
		System.out.println("Application is paused while adjustment report runs");
		PurchaseDb db = PurchaseDb.getInstance();
		
		System.out.println("TOTAL ADJUSTMENTS MADE TO ALL SALES");
		System.out.println("===================================");
		for(Purchase purchase : db.getAllPurchases()) {
			System.out.println(purchase.toString());
		}
		System.out.println("===================================");
		System.out.println("Application is resuming...\n");
	}
	
	
	
	Map<String, PurchaseTouple> consolodateOrders() {
		PurchaseDb db = PurchaseDb.getInstance();

		Map<String, PurchaseTouple> totalPurchases = new HashMap<>();

		for(Purchase purchase : db.getAllPurchases()) {
			int sales = purchase.getQuantity() * purchase.getPrice();

			if(totalPurchases.containsKey(purchase.getProduct())) {
				// append the quantity and sale price
				int currentSales = totalPurchases.get(purchase.getProduct()).totalSales;
				int currentQuantity = totalPurchases.get(purchase.getProduct()).quantity;
				totalPurchases.put(purchase.getProduct(), new PurchaseTouple(currentQuantity + purchase.getQuantity(), currentSales + sales));
			} else {
				//add new entry
				totalPurchases.put(purchase.getProduct(), new PurchaseTouple(purchase.getQuantity(), sales));
			}
		}
		return totalPurchases;
	}

	class PurchaseTouple {
		public int quantity;
		public int totalSales;

		public PurchaseTouple(int quantity, int totalSales) {
			this.quantity = quantity;
			this.totalSales = totalSales;
		}
	}

}
