package com.rdemarco.tradingcards.db;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.rdemarco.tradingcards.model.Purchase;

/**
 * This class will act as our data store for all purchases
 *
 */
public class PurchaseDb {

	private List<Purchase> allPurchases;
	private Map<String, Integer> groupedProducts;
	private static PurchaseDb instance;

	private PurchaseDb() {
		instance = this;
		allPurchases = new ArrayList<>();
		groupedProducts = new HashMap<>();
	}

	/**
	 * Ensure we only have a single instance
	 */
	public static PurchaseDb getInstance() {
		if (instance == null) {
			return new PurchaseDb();
		} 
		return instance;
	}

	/**
	 * Adds a purchase to the list of purchases, then adds the purchase quantity to any existing purchases of the same product.
	 * @param purchase
	 */
	public void addPurchase(Purchase purchase) {
		allPurchases.add(purchase);
		mapProduct(purchase);
	}
	
	private void mapProduct(Purchase purchase) {
		String productName = purchase.getProduct();

		if(groupedProducts.containsKey(productName)) {
			int currentQuantity = groupedProducts.get(productName);
			groupedProducts.put(productName, currentQuantity + purchase.getQuantity());
		} else {
			groupedProducts.put(productName, purchase.getQuantity());
		}
	}

	public List<Purchase> getAllPurchases() {
		return allPurchases;
	}

	public Map<String, Integer> getGroupedProducts() {
		return groupedProducts;
	}

}
