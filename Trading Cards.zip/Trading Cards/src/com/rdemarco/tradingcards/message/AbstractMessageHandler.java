package com.rdemarco.tradingcards.message;

import com.rdemarco.tradingcards.db.PurchaseDb;
import com.rdemarco.tradingcards.exception.InsufficientParametersException;
import com.rdemarco.tradingcards.model.Purchase;

public abstract class AbstractMessageHandler implements MessageHandler {
	
	String[] parameters;
	PurchaseDb purchaseDb;
	private String rawMessage;
	
	protected AbstractMessageHandler(String message) {
		parameters = message.split(",");
		purchaseDb = PurchaseDb.getInstance();
		rawMessage = message;
	}
	
	@Override
	public String handleMessage(long id) throws InsufficientParametersException {
		System.out.println("processing message - " + rawMessage);
		return handleMessageInternal(id);
	}
	
	protected String finishedProcessing(Purchase purchase) {
		return "Finished processing message with ID = " + purchase.getId();
	}
	
	protected void validateParameters(int numParams) throws InsufficientParametersException {
		if (parameters.length != numParams) {
			throw new InsufficientParametersException(String.format("There are %s parameters, but %s are required for message type 1", parameters.length, numParams));
		}
	}
	
	protected abstract String handleMessageInternal(long id) throws InsufficientParametersException;

}
