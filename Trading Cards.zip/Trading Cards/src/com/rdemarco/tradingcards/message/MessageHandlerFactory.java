package com.rdemarco.tradingcards.message;

import com.rdemarco.tradingcards.exception.UnknownMessageTypeException;

public class MessageHandlerFactory {

	public static MessageHandler getMessageHandlerInstance(String message) throws UnknownMessageTypeException {
		String messageType = message.split(",")[0];

		switch(messageType) {
		case "1":
			return new SinglePurchaseHandler(message);
		case "2":
			return new MultiplePurchaseHandler(message);
		case "3":
			return new AdjustProductHandler(message);
		default: 
			throw new UnknownMessageTypeException("Message type: " + messageType + " is unsupported");
		}

	}


}
