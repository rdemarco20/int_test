package com.rdemarco.tradingcards.message;

import com.rdemarco.tradingcards.exception.InsufficientParametersException;
import com.rdemarco.tradingcards.model.Purchase;

/**
 * This class will handle Message type 1, which is for a purchase of a single product
 * 
 * The parameters for this will be in the following order, with the delimiter as a comma ',':
 * 		message type
 * 		product type
 * 		price in pence
 * 		
 * example: "1,Charizard,5000"
 *
 */
public class SinglePurchaseHandler extends AbstractMessageHandler {
	
	private static int EXPECTED_NUM_PARAMS = 3;

	protected SinglePurchaseHandler(String message) {
		super(message);
	}

	@Override
	protected String handleMessageInternal(long id) throws InsufficientParametersException {
		validateParameters(EXPECTED_NUM_PARAMS);
		
		String productName = parameters[1].trim();
		int price = Integer.parseInt(parameters[2].trim());
		
		Purchase purchase = new Purchase(id, productName, price);
		purchaseDb.addPurchase(purchase);
		return finishedProcessing(purchase);
	}

}
