package com.rdemarco.tradingcards.message;

import com.rdemarco.tradingcards.model.Purchase;

/**
 * This class will handle Message type 3, which is for adjusting the purchase price of all previous orders
 * 
 * The parameters for this will be in the following order, with the delimiter as a comma ',':
 * 		message type
 * 		product type
 * 		operation to perform (add, subtract, multiply)
 * 		price adjustment in pence
 * 		
 * example: "3,Charizard,add,50"
 *
 */
public class AdjustProductHandler extends AbstractMessageHandler {
	

	protected AdjustProductHandler(String message) {
		super(message);
	}

	@Override
	protected String handleMessageInternal(long id) {
		String product = parameters[1].trim();
		String operation = parameters[2].trim();
		int adjustment = Integer.parseInt(parameters[3].trim());
		
		switch(operation) {
		case "add":
			addToAllPurchases(adjustment, product);
			break;
		case "subtract":
			subtractFromAllPurchases(adjustment, product);
			break;
		case "multiply":
			multiplyAllPurchases(adjustment, product);
			break;
		default:
			throw new UnsupportedOperationException(String.format("Operation %s is not supported, try add, subtract, or multiply", operation));
		}
		return "Finished processing message with Id " + id;
	}

	public void addToAllPurchases(int adjustment, String product) {
		for (Purchase purchase : purchaseDb.getAllPurchases()) {
			if (purchase.getProduct().equals(product)) {
				int previous = purchase.getPrice();
				int newPrice = previous + adjustment;
				purchase.setPrice(newPrice);
				purchase.addAdjustment("add " + adjustment);
			}
		}
	}

	public void multiplyAllPurchases(int multiplyBy, String product) {
		for (Purchase purchase : purchaseDb.getAllPurchases()) {
			if (purchase.getProduct().equals(product)) {
				int previous = purchase.getPrice();
				int newPrice = previous * multiplyBy;
				purchase.setPrice(newPrice);
				purchase.addAdjustment("multiply " + multiplyBy);
			}
		}
	}

	/**
	 * I have assumed that we wont care if the subtract
	 * @param subtract
	 * @param product
	 */
	public void subtractFromAllPurchases(int subtract, String product) {
		for (Purchase purchase : purchaseDb.getAllPurchases()) {
			if (purchase.getProduct().equals(product)) {
				int previous = purchase.getPrice();
				int newPrice = previous - subtract;
				purchase.setPrice(newPrice);
				purchase.addAdjustment("subtract " + subtract);
			}
		}
	}

}
