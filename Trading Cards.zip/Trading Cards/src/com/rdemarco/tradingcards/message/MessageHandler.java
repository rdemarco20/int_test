package com.rdemarco.tradingcards.message;

import com.rdemarco.tradingcards.exception.InsufficientParametersException;

public interface MessageHandler {
	
	/**
	 * @param id - id to give the message
	 * @return message processed confirmation
	 * @throws InsufficientParametersException
	 */
	String handleMessage(long id) throws InsufficientParametersException;

}
