package com.rdemarco.tradingcards.message;

import com.rdemarco.tradingcards.exception.InsufficientParametersException;
import com.rdemarco.tradingcards.model.Purchase;

/**
 * This class will handle Message type 2, which is for a purchase of multiples of the same product
 * 
 * The parameters for this will be in the following order, with the delimiter as a comma ',':
 * 		message type
 * 		product type
 * 		price in pence
 * 		quantity
 * 		
 * example: "2,Charizard,5000,3"
 *
 */
public class MultiplePurchaseHandler extends AbstractMessageHandler {
	
	private static final int EXPECTED_NUM_PARAMS = 4;

	public MultiplePurchaseHandler(String message) {
		super(message);
	}

	@Override
	protected String handleMessageInternal(long id) throws InsufficientParametersException {
		validateParameters(EXPECTED_NUM_PARAMS);
		
		String productName = parameters[1].trim();
		int price = Integer.parseInt(parameters[2].trim());
		int quantity = Integer.parseInt(parameters[3].trim());
		
		Purchase purchase = new Purchase(id, productName, price, quantity);
		purchaseDb.addPurchase(purchase);
		return finishedProcessing(purchase);
	}
}
